-- MySQL Workbench Synchronization
-- Generated: 2024-12-11 10:06
-- Model: New Model
-- Version: 1.0
-- Project: Name of the project
-- Author: Linnk

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

ALTER TABLE `mydb`.`tarefas` 
DROP FOREIGN KEY `fk_tarefas_categoria1`;

ALTER TABLE `mydb`.`usuario_has_tarefas` 
DROP FOREIGN KEY `fk_table1_tarefas1`;

ALTER TABLE `mydb`.`usuario` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `mydb`.`tarefas` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ,
ADD INDEX `fk_tarefas_status_idx` (`status_id` ASC) VISIBLE,
ADD INDEX `fk_tarefas_categoria1_idx` (`categoria_id` ASC) VISIBLE,
DROP INDEX `fk_tarefas_categoria1_idx` ,
DROP INDEX `fk_tarefas_status_idx` ;
;

ALTER TABLE `mydb`.`categoria` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `mydb`.`status` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `mydb`.`usuario_has_tarefas` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ,
DROP COLUMN `tarefas_id`,
DROP COLUMN `usuario_id`,
ADD COLUMN `usuario_id` INT(11) NOT NULL FIRST,
ADD COLUMN `tarefas_id` INT(11) NOT NULL AFTER `usuario_id`,
ADD INDEX `fk_table1_usuario1_idx` (`usuario_id` ASC) VISIBLE,
ADD INDEX `fk_table1_tarefas1_idx` (`tarefas_id` ASC) VISIBLE,
DROP INDEX `fk_table1_tarefas1_idx` ,
DROP INDEX `fk_table1_usuario1_idx` ;
ALTER TABLE `mydb`.`usuario_has_tarefas` ALTER INDEX `PRIMARY` VISIBLE;

ALTER TABLE `mydb`.`tarefas` 
DROP FOREIGN KEY `fk_tarefas_status`;

ALTER TABLE `mydb`.`tarefas` ADD CONSTRAINT `fk_tarefas_status`
  FOREIGN KEY (`status_id`)
  REFERENCES `mydb`.`status` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_tarefas_categoria1`
  FOREIGN KEY (`categoria_id`)
  REFERENCES `mydb`.`categoria` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `mydb`.`usuario_has_tarefas` 
DROP FOREIGN KEY `fk_table1_usuario1`;

ALTER TABLE `mydb`.`usuario_has_tarefas` ADD CONSTRAINT `fk_table1_usuario1`
  FOREIGN KEY (`usuario_id`)
  REFERENCES `mydb`.`usuario` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_table1_tarefas1`
  FOREIGN KEY (`tarefas_id`)
  REFERENCES `mydb`.`tarefas` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
