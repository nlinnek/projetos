<?php
    class BD {
        public static function connect() {
            try {
                $conn = new PDO('mysql:host=localhost;dbname=bd_agenda', 
                                'root', 
                                'root');
                //echo "<p>Conexão bem sucedida";
            } catch(PDOException $e) {
                echo 'ERROR: ' . $e->getMessage();
            }

            return $conn;
        }
    }
?>