<?php
    class UsuarioDAO {
        public function create($usuario) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO usuario(nomeUsuario,email,senha) 
                    VALUES (:n, :e, md5(:s)"
                );
                $query->bindValue(':n',$usuario->getNomeUsuario(),PDO::PARAM_STR);
                $query->bindValue(':e',$usuario->getEmail(),PDO::PARAM_STR);
                $query->bindValue(':s',$usuario->getSenha(),PDO::PARAM_STR);
             

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao cadastrar Usuário. Erro: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM usuario"
            );
                
                $query->execute();

                $usuarios = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $usuario = new Usuario();
                 

                    $usuario->setId($linha['id']);
                    $usuario->setNomeUsuario($linha['nomeUsuario']);
                    $usuario->setEmail($linha['email']);
                    

                    array_push($usuarios,$usuario);
                }

                return $usuarios;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao consultar usuários. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM usuario WHERE id = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $usuario = new Usuario();

                    $usuario->setId($linha['id']);
                    $usuario->setNomeUsuario($linha['nomeUsuario']);
                    $usuario->setEmail($linha['email']);
                    
                }

                return $usuario;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao buscar usuário. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($usuario) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE usuario
                     SET nomeUsuario = :n, email = :e, senha = md5(:s)
                     WHERE id = :i"
                );
                $query->bindValue(':n',$usuario->getNomeUsuario(),PDO::PARAM_STR);
                $query->bindValue(':e',$usuario->getEmail(),PDO::PARAM_STR);
                $query->bindValue(':s',$usuario->getSenha(),PDO::PARAM_STR);
                $query->bindValue(':i',$usuario->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao editar usuário. Erro: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM usuario
                     WHERE id = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao excluir usuário. Erro: " . $e->getMessage();
            }
        }
    }