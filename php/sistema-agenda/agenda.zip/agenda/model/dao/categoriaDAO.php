<?php
    class categoriaDAO {
        public function create($categoria) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO categoria(nome) 
                    VALUES (:n)"
                );
                $query->bindValue(':n',$categoria->getNome(),PDO::PARAM_STR);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>Erro no CREATE: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM categoria"
                );
                
                $query->execute();

                $categorias = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $categoria = new categoria();

                    $categoria->setId($linha['id_categoria']);
                    $categoria->setNome($linha['nome']);

                    array_push($categorias,$categoria);
                }

                return $categorias;
            }
            catch(PDOException $e) {
                echo "<p>Erro no CREATE: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM categoria WHERE id_categoria = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $categoria = new Categoria();

                    $categoria->setId($linha['id_categoria']);
                    $categoria->setNome($linha['nome']);

                }

                return $categoria;
            }
            catch(PDOException $e) {
                echo "<p>Falha ao buscar usuário. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($categoria) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE categoria
                     SET nome = :n
                     WHERE id_categoria = :i"
                );
                $query->bindValue(':n',$categoria->getNome(),PDO::PARAM_STR);
                $query->bindValue(':i',$categoria->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>Erro no UPDATE: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM categoria
                     WHERE id_categoria = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>Erro no DELETE: " . $e->getMessage();
            }
        }
    }