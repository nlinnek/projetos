<?php
    class statusDAO {
        public function create($status) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO status(descricao) 
                    VALUES (:n)"
                );
                
                $query->bindValue(':n',$status->getDescricao(),PDO::PARAM_STR);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>Erro no CREATE: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM status"
                );
                
                $query->execute();

                $statuss = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $status = new Status();

                    $status->setId($linha['id']);
                    $status->setDescricao($linha['descricao']);

                    array_push($status,$status);
                }

                return $statuss;
            }
            catch(PDOException $e) {
                echo "<p>Erro no CREATE: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM status WHERE id_status = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $status = new status();

                    $status->setId($linha['id_status']);
                    $status->setdescricao($linha['descricao']);
                }

                return $status;
            }
            catch(PDOException $e) {
                echo "<p>Falha ao buscar usuário. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($status) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE status
                     SET descricao = :n
                     WHERE id_status = :i"
                );
                $query->bindValue(':n',$status->getDescricao(),PDO::PARAM_STR);
                $query->bindValue(':i',$status->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>Erro no UPDATE: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM status
                     WHERE id_status = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>Erro no DELETE: " . $e->getMessage();
            }
        }
    }