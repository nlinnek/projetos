<?php
    require "../../autoload.php";

    $dao = new categoriaDAO();
    $dao->destroy($_GET['id']);

    header('Location: index.php');