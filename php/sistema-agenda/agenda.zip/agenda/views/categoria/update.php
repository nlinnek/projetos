<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $categoria = new Categoria();
    $categoria->setNome($_POST['nome']);

    // Instanciar um objeto da classe DAO
    $dao = new categoriaDAO();
    $dao->update($categoria);

    // Redirecionar para o index
    header('Location: index.php');