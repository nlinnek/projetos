<?php
    require "../../autoload.php";

    $dao = new statusDAO();
    $dao->destroy($_GET['id']);

    header('Location: index.php');