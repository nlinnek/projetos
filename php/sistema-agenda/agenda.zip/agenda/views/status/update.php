<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $status = new Status();
    $status->setDescricao($_POST['descricao']);

    // Instanciar um objeto da classe DAO
    $dao = new statusDAO();
    $dao->update($status);

    // Redirecionar para o index
    header('Location: index.php');