<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $usuario = new Usuario();
    $usuario->setNomeUsuario($_POST['nomeUsuario']);
    $usuario->setEmail($_POST['email']);
    $usuario->setSenha($_POST['senha']);

    // Instanciar um objeto da classe DAO
    $dao = new UsuarioDAO();
    $dao->create($usuario);

    // Redirecionar para o index
    header('Location: index.php');