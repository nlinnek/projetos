<?php
    if (!function_exists('str_contains')) {
        function str_contains(string $haystack, string $needle): bool
        {
            return '' === $needle || false !== strpos($haystack, $needle);
        }
    }
    
    spl_autoload_register(function ($class_name) {
        if($class_name == "BD" || str_contains($class_name,"DAO")) {
            require '../../model/dao/' . $class_name . '.php';
        }
        else {
            require '../../model/bean/' . $class_name . '.php';
        }
    });
    function renderNavbar() {
        echo '
        <nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../../biblioteca">Home</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
                    aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav me-auto mb-2 mb-md-0">
                        <li class="nav-item">
                            <a class="nav-link" href="../usuario">Usuário</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../autor">Autor</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../editora">Editora</a>
                        </li>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../Status_emprestimo">Status Emprestimo</a>
                        </li>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../Perfil">Perfil</a>
                        </li>
                    </ul>
                    <form class="d-flex" role="search">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>';
    }