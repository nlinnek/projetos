<?php
    class AutorDAO {
        public function create($autor) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO autor(nome) 
                    VALUES (:n)"
                );
                $query->bindValue(':n',$autor->getNome(),PDO::PARAM_STR);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao cadastrar autor. Erro: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM autor"
                );
                
                $query->execute();

                $autores = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $autor = new autor();

                    $autor->setId($linha['id_autor']);
                    $autor->setNome($linha['nome']);

                   array_push($autores,$autor);
                }

                return $autores;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao consultar autor. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM autor WHERE id_autor = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $autor = new autor();

                    $autor->setId($linha['id_autor']);
                    $autor->setNome($linha['nome']);
                }

                return $autor;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao buscar autor. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($autor) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE autor
                     SET nome = :n
                     WHERE id_autor = :i"
                );
                $query->bindValue(':n',$autor->getNome(),PDO::PARAM_STR);
                $query->bindValue(':i',$autor->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao editar autor. Erro: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM autor
                     WHERE id_autor = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao excluir autor. Erro: " . $e->getMessage();
            }
        }
    }