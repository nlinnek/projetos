<?php
    class EditoraDAO {
        public function create($editora) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO editora(nome) 
                    VALUES (:n)"
                );
                $query->bindValue(':n',$editora->getNome(),PDO::PARAM_STR);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao cadastrar editora. Erro: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM editora"
                );
                
                $query->execute();

                $editoraes = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $editora = new editora();

                    $editora->setId($linha['id_editora']);
                    $editora->setNome($linha['nome']);

                   array_push($editoraes,$editora);
                }

                return $editoraes;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao consultar editora. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM editora WHERE id_editora = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $editora = new editora();

                    $editora->setId($linha['id_editora']);
                    $editora->setNome($linha['nome']);
                }

                return $editora;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao buscar editora. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($editora) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE editora
                     SET nome = :n
                     WHERE id_editora = :i"
                );
                $query->bindValue(':n',$editora->getNome(),PDO::PARAM_STR);
                $query->bindValue(':i',$editora->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao editar editora. Erro: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM editora
                     WHERE id_editora = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao excluir editora. Erro: " . $e->getMessage();
            }
        }
    }