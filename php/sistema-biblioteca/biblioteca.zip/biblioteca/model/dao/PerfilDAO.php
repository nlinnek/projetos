<?php
    class PerfilDAO {
        public function create($perfil) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO perfil(descricao) 
                    VALUES (:n)"
                );
                $query->bindValue(':n',$perfil->getDescricao(),PDO::PARAM_STR);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao cadastrar perfil. Erro: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM perfil"
                );
                
                $query->execute();

                $perfis = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $perfil = new Perfil();

                    $perfil->setId($linha['id_perfil']);
                    $perfil->setdescricao($linha['descricao']);

                   array_push($perfis,$perfil);
                }

                return $perfis;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao consultar perfil. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM perfil WHERE id_perfil = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $perfil = new Perfil();

                    $perfil->setId($linha['id_perfil']);
                    $perfil->setDescricao($linha['descricao']);
                }

                return $perfil;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao buscar perfil. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($perfil) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE perfil
                     SET descricao = :n
                     WHERE id_perfil = :i"
                );
                $query->bindValue(':n',$perfil->getDescricao(),PDO::PARAM_STR);
                $query->bindValue(':i',$perfil->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao editar perfil. Erro: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM perfil
                     WHERE id_perfil = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao excluir perfil. Erro: " . $e->getMessage();
            }
        }
    }