<?php
    class Status_emprestimoDAO {
        public function create($status_emprestimo) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO status_emprestimo(descricao) 
                    VALUES (:n)"
                );
                $query->bindValue(':n',$status_emprestimo->getdescricao(),PDO::PARAM_STR);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao cadastrar status emprestimo. Erro: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM status_emprestimo"
                );
                
                $query->execute();

                $status_emprestimoes = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $status_emprestimo = new status_emprestimo();

                    $status_emprestimo->setId($linha['id_status_emprestimo']);
                    $status_emprestimo->setdescricao($linha['descricao']);

                   array_push($status_emprestimoes,$status_emprestimo);
                }

                return $status_emprestimoes;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao consultar status_emprestimo. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM status_emprestimo WHERE id_status_emprestimo = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $status_emprestimo = new status_emprestimo();

                    $status_emprestimo->setId($linha['id_status_emprestimo']);
                    $status_emprestimo->setdescricao($linha['descricao']);
                }

                return $status_emprestimo;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao buscar status_emprestimo. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($status_emprestimo) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE status_emprestimo
                     SET descricao = :n
                     WHERE id_status_emprestimo = :i"
                );
                $query->bindValue(':n',$status_emprestimo->getdescricao(),PDO::PARAM_STR);
                $query->bindValue(':i',$status_emprestimo->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao editar status_emprestimo. Erro: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM status_emprestimo
                     WHERE id_status_emprestimo = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao excluir status_emprestimo. Erro: " . $e->getMessage();
            }
        }
    }