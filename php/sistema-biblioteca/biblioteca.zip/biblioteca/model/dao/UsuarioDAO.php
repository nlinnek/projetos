<?php
    class UsuarioDAO {
        public function create($usuario) {
            try {
                $query = BD::connect()->prepare(
                    "INSERT INTO usuario(nome,email,senha,id_perfil) 
                    VALUES (:n, :e, md5(:s), :p)"
                );
                $query->bindValue(':n',$usuario->getNome(),PDO::PARAM_STR);
                $query->bindValue(':e',$usuario->getEmail(),PDO::PARAM_STR);
                $query->bindValue(':s',$usuario->getSenha(),PDO::PARAM_STR);
                $query->bindValue(':p',$usuario->getPerfil()->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao cadastrar Usuário. Erro: " . $e->getMessage();
            }
        }

        public function read() {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM usuario"
                );
                
                $query->execute();

                $usuarios = array();
                foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha) {
                    $usuario = new Usuario();
                    $perfilDAO = new PerfilDAO();

                    $usuario->setId($linha['id_usuario']);
                    $usuario->setNome($linha['nome']);
                    $usuario->setEmail($linha['email']);
                    $usuario->setPerfil($perfilDAO->find($linha['id_perfil']));

                    array_push($usuarios,$usuario);
                }

                return $usuarios;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao consultar usuários. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function find($id) {
            try {
                $query = BD::connect()->prepare(
                    "SELECT * FROM usuario WHERE id_usuario = :i"
                );
                $query->bindValue(':i', $id, PDO::PARAM_INT);
                
                $query->execute();

                if($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                    $usuario = new Usuario();
                    $perfilDAO = new PerfilDAO();

                    $usuario->setId($linha['id_usuario']);
                    $usuario->setNome($linha['nome']);
                    $usuario->setEmail($linha['email']);
                    $usuario->setPerfil($perfilDAO->find($linha['id_perfil']));
                }

                return $usuario;
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao buscar usuário. Erro: " . $e->getMessage();
            }

            return null;
        }

        public function update($usuario) {
            try {
                $query = BD::connect()->prepare(
                    "UPDATE usuario
                     SET nome = :n, email = :e, senha = md5(:s), id_perfil = :p
                     WHERE id_usuario = :i"
                );
                $query->bindValue(':n',$usuario->getNome(),PDO::PARAM_STR);
                $query->bindValue(':e',$usuario->getEmail(),PDO::PARAM_STR);
                $query->bindValue(':s',$usuario->getSenha(),PDO::PARAM_STR);
                $query->bindValue(':p',$usuario->getPerfil()->getId(),PDO::PARAM_INT);
                $query->bindValue(':i',$usuario->getId(),PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao editar usuário. Erro: " . $e->getMessage();
            }
        }

        public function destroy($id) {
            try {
                $query = BD::connect()->prepare(
                    "DELETE FROM usuario
                     WHERE id_usuario = :i"
                );
                $query->bindValue(':i',$id,PDO::PARAM_INT);

                $query->execute();
            }
            catch(PDOException $e) {
                echo "<p>FALHA ao excluir usuário. Erro: " . $e->getMessage();
            }
        }
    }