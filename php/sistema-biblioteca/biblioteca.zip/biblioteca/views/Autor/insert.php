<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $autor = new Autor();
    $autor->setNome($_POST['nome']);
    
    // Instanciar um objeto da classe DAO
    $dao = new AutorDAO();
    $dao->create($autor);

    // Redirecionar para o index
    header('Location: index.php');