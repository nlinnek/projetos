<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $autor = new Autor();
    $autor->setNome($_POST['nome']);
    $autor->setId($_POST['id']);
    
    // Instanciar um objeto da classe DAO
    $dao = new autorDAO();
    $dao->update($autor);

    // Redirecionar para o index
    header('Location: index.php');