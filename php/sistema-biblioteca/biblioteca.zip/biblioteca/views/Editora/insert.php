<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $editora = new Editora();
    $editora->setNome($_POST['nome']);
    
    // Instanciar um objeto da classe DAO
    $dao = new EditoraDAO();
    $dao->create($editora);

    // Redirecionar para o index
    header('Location: index.php');