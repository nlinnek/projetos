<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $editora = new Editora();
    $editora->setNome($_POST['nome']);
    $editora->setId($_POST['id']);
    
    // Instanciar um objeto da classe DAO
    $dao = new EditoraDAO();
    $dao->update($editora);

    // Redirecionar para o index
    header('Location: index.php');