<?php
    require "../../autoload.php";

    $dao = new PerfilDAO();
    $dao->destroy($_GET['id']);

    header('Location: index.php');