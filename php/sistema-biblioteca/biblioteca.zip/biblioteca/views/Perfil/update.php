<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $perfil = new Perfil();
    $perfil->setDescricao($_POST['descricao']);
    $perfil->setId($_POST['id']);
    
    // Instanciar um objeto da classe DAO
    $dao = new PerfilDAO();
    $dao->update($perfil);

    // Redirecionar para o index
    header('Location: index.php');