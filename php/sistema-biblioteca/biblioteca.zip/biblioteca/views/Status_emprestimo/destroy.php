<?php
    require "../../autoload.php";

    $dao = new Status_emprestimoDAO();
    $dao->destroy($_GET['id']);

    header('Location: index.php');