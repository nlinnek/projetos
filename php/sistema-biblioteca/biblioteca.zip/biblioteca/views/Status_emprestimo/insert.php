<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $status_emprestimo = new Status_emprestimo();
    $status_emprestimo->setDescricao($_POST['descricao']);
    
    // Instanciar um objeto da classe DAO
    $dao = new Status_emprestimoDAO();
    $dao->create($status_emprestimo);

    // Redirecionar para o index
    header('Location: index.php');