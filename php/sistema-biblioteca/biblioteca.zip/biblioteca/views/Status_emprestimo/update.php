<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $status_emprestimo = new Status_emprestimo();
    $status_emprestimo->setDescricao($_POST['descricao']);
    $status_emprestimo->setId($_POST['id']);
    
    // Instanciar um objeto da classe DAO
    $dao = new Status_emprestimoDAO();
    $dao->update($status_emprestimo);

    // Redirecionar para o index
    header('Location: index.php');