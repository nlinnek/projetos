<?php
    require "../../autoload.php";

    $dao = new UsuarioDAO();
    $dao->destroy($_GET['id']);

    header('Location: index.php');