<?php
    // Incluir o arquivo bean
    require "../../autoload.php";

    // Instanciar um objeto da classe bean
    $usuario = new Usuario();
    $usuario->setNome($_POST['nome']);
    $usuario->setEmail($_POST['email']);
    $usuario->setSenha($_POST['senha']);

    // Trecho para a chave estrangeira
    $perfilDAO = new PerfilDAO();
    $perfil = $perfilDAO->find($_POST['id_perfil']);
    $usuario->setPerfil($perfil);

    // Instanciar um objeto da classe DAO
    $dao = new UsuarioDAO();
    $dao->create($usuario);

    // Redirecionar para o index
    header('Location: index.php');